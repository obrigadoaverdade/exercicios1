import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

builder = Gtk.Builder()
builder.add_from_file("interface.glade")

class Rendimento:

    saldoCaixa = builder.get_object("saldoCaixa")
    valor_aplicadoCaixa = builder.get_object("valor_aplicadoCaixa")

    lb_aplicado = builder.get_object("lb_aplicado")
    lb_rendimento = builder.get_object("lb_rendimento")
  
    def onDestroy(self, *args):
        Gtk.main_quit()

    def calcularRendimento(self, button):
        saldo = float(self.saldoCaixa.get_text())
        valor_aplicado = float(self.valor_aplicadoCaixa.get_text())

        valor_rendimento = saldo + valor_aplicado + (valor_aplicado * 5/100)
        
        self.lb_aplicado.set_text(str(valor_aplicado))
        self.lb_rendimento.set_text(str(valor_rendimento))

builder.connect_signals(Rendimento())


window = builder.get_object("FrmRendimento")
window.show_all()

Gtk.main()
