import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

builder = Gtk.Builder()
builder.add_from_file("interface.glade")

class Salario:

    hora_aulaCaixa = builder.get_object("hora_aulaCaixa")
    horas_mesCaixa = builder.get_object("horas_mesCaixa")
    descontoCaixa = builder.get_object("descontoCaixa")

    lb_liquido = builder.get_object("lb_liquido")
  
    def onDestroy(self, *args):
        Gtk.main_quit()

    def calcularMedia(self, button):
        hora_aula = float(self.hora_aulaCaixa.get_text())
        horas_mes = float(self.horas_mesCaixa.get_text())
        desconto = float(self.descontoCaixa.get_text())

        valor_bruto = (hora_aula * horas_mes)
        valor_liquido = valor_bruto - ((desconto/100) * valor_bruto)
        
        self.lb_liquido.set_text(str(valor_liquido))

builder.connect_signals(Salario())


window = builder.get_object("FrmSalario")
window.show_all()

Gtk.main()
