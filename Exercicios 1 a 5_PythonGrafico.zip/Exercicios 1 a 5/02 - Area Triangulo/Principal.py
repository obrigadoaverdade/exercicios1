import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

builder = Gtk.Builder()
builder.add_from_file("interface.glade")

class Triangulo:

    baseCaixa = builder.get_object("baseCaixa")
    alturaCaixa = builder.get_object("alturaCaixa")

    lb_area = builder.get_object("lb_area")
  
    def onDestroy(self, *args):
        Gtk.main_quit()

    def calcularArea(self, button):
        base = float(self.baseCaixa.get_text())
        altura = float(self.alturaCaixa.get_text())

        area = (base * altura)/2
        self.lb_area.set_text(str(area))

builder.connect_signals(Triangulo())


window = builder.get_object("FrmTriangulo")
window.show_all()

Gtk.main()
