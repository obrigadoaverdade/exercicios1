import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

builder = Gtk.Builder()
builder.add_from_file("interface.glade")

class Handler:

    nota1Caixa = builder.get_object("nota1Caixa")
    nota2Caixa = builder.get_object("nota2Caixa")
    nota3Caixa = builder.get_object("nota3Caixa")
    nota4Caixa = builder.get_object("nota4Caixa")
    nota5Caixa = builder.get_object("nota5Caixa")

    lb_media = builder.get_object("lb_media")
  
    def onDestroy(self, *args):
        Gtk.main_quit()

    def calcularMedia(self, button):
        nota1 = float(self.nota1Caixa.get_text())
        nota2 = float(self.nota2Caixa.get_text())
        nota3 = float(self.nota3Caixa.get_text())
        nota4 = float(self.nota4Caixa.get_text())
        nota5 = float(self.nota5Caixa.get_text())        
        media = (nota1 + nota2 + nota3 + nota4 + nota5)/5
        self.lb_media.set_text(str(media))

builder.connect_signals(Handler())


window = builder.get_object("Form1")
window.show_all()

Gtk.main()
